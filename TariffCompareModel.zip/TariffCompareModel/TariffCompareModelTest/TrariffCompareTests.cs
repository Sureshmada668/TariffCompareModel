﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using TariffCompareModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TariffCompareModel.Tests
{
    [TestClass()]
    public class TariffCompareTests
    {
        [TestMethod()]
        public void CompareProductsTest_ValidValues()
        {

            //3500 test
            var tariffList= TariffCompare.GetCompareProductList(3500);
            Assert.IsNotNull(tariffList);
            Assert.IsTrue(tariffList.Count() > 1);
            Assert.IsTrue(tariffList[0].AnnualCosts < tariffList[1].AnnualCosts);

            //4500 Test
            tariffList = TariffCompare.GetCompareProductList(4500);
            Assert.IsNotNull(tariffList);
            Assert.IsTrue(tariffList.Count() > 1);
            Assert.IsTrue(tariffList[0].AnnualCosts< tariffList[1].AnnualCosts);

            //6000 test 
            tariffList = TariffCompare.GetCompareProductList(6000);
            Assert.IsNotNull(tariffList);
            Assert.IsTrue(tariffList.Count() > 1);
            Assert.AreEqual(tariffList[0].TariffName, "basic electricity tariff");
            
        }

        [TestMethod()]
        [ExpectedException(typeof(ArgumentException))]
        public void CompareProductTest_InvalidData()
        {
            TariffCompare.GetCompareProductList(-3500);
        }
    }
}