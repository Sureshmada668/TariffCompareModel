﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TariffCompareModel
{
    
    //Base interface created for all Tariffs
    public interface ITariff
    {
        double GetAnnualCost(int consumption);
    }


    /// <summary>
    /// Calcualtes annual cost of the "Base Eletricity Tariff"  and can be extended in future.
    /// </summary>
    public class BasicEletricityTariff : ITariff
    {
        private const int baseTariff = 5;//Can be configurable
        public double GetAnnualCost(int consumption)
        {
            return (baseTariff * 12) + (consumption * 0.22);
        }
    }

    /// <summary>
    /// Calcualtes annual cost of the "Packaged Tariff"  and can be extended in future.
    /// </summary>
    public class PackagedTariff : ITariff
    {
        private int ConsumptionThreshold = 4000; // can be configurable
        public double GetAnnualCost(int consumption)
        {
            if (consumption <= ConsumptionThreshold)
                return 800;
            else
                return 800 + ((consumption - ConsumptionThreshold) * 0.30);
        }
    }

    /// <summary>
    /// Tariff Business entity.
    /// </summary>
    public class Product
    {
        public string TariffName { get; set; }
        public double AnnualCosts { get; set; }
    }
    class TariffBusinessLogic
    {

    }
}
