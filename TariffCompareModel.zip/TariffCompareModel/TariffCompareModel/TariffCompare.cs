﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace TariffCompareModel
{
    public class TariffCompare
    {
        //HArd coded valid product list and It can be retrieved from the the DB in future
        private static List<string> ValidProducts = new List<string>() { "basic electricity tariff", "packaged tariff" };

        #region Methods
        /// <summary>
        /// Returns List of all valid products based on Consumption  
        /// </summary>
        /// <param name="consumptionPerYear">Consumption per year(KWH)</param>
        /// <returns></returns>
        public static List<Product> GetCompareProductList(int consumptionPerYear)
        {
            List<Product> products =null;
            Product product = null;
            ITariff tariff = null;

            //validating the Consumption value either negative or postive.
            if (consumptionPerYear <= 0)
            {
                throw new ArgumentException("ConsumptionPerYear value should not be zero or Negative");
            }
            else
            {
                products = new List<Product>();
                foreach (var tariffName in ValidProducts)
                {
                    product = new Product();
                    product.TariffName = tariffName;

                    switch (tariffName)
                    {
                        // Hardcoding now as less number of the products. otherwise we can eloborate with design patterns
                        case "basic electricity tariff": 
                            tariff = new BasicEletricityTariff();
                            break;

                        case "packaged tariff":
                            tariff = new PackagedTariff();
                            break;
                    }

                    product.AnnualCosts=(tariff != null ? tariff.GetAnnualCost(consumptionPerYear) : 0);
                    products.Add(product);
                }
              
            }
            return products.OrderBy(x=>x.AnnualCosts).ToList();
        }
        #endregion
    }
}
